import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import javax.swing.Timer;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BasicStroke;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;
import org.json.JSONObject;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import javax.swing.SwingConstants;
import javax.swing.JRadioButton;
import javax.swing.JTextPane;

public class GameScreen extends JFrame implements ActionListener, KeyListener {

	private JPanel contentPane;											// Declare the content pane of the application
	private JLabel lblTeam;												// Declare a label to display the team
	private static final Integer FRAMETIME = 16;                        // Initialize a constant integer for the frame time
	private Timer tickTock = new Timer(FRAMETIME,this);					// Initialize a timer variable and instantiate the timer class
	private JPanel panel;												// Declare a panel for the game area 
	private List<Player> players = new ArrayList<>();					// Initialize a list of players to keep track of them
    private Player currentPlayer;										// Declare a player variable to keep track of the current player
	private String ipAddress;											// Declare a string data member to store the ip address of the server
	private String username;											// Declare a string data member to store the player's username
	private short radiusAttack = 20;									// Initialize  a short to set the attack radius
	private short counterTicks = 0;										// Initialize a short to count time during the execution
	private short counterTicksResult = 120;								// Initialize a short to count time during the execution
	private PlayerConnection playerConnection;							// Instantiate the player connection
	private String status;												// Declare string variable to store the status
	private boolean firstSetup = true;									// Declare a boolean variable to determine if its the first setup
	private short playerLives;											// Declare a short data member to track the player's lives
	private int scoreTeam1;												// Declare an integer data member to store team 1's score 
	private int scoreTeam2;												// Declare an integer data member to store team 2's score 
	private boolean endRound = false;									// Declare a boolean to flag when the round must end
	private JLabel lblScoreTeam1;										// Declare a label to display team 1's score 
	private JLabel lblScoreTeam2;										// Declare a label to display team 2's score 
	private JLabel lblAnnouncement = new JLabel("ROUND 1!");			// Initialize a label to announce the end of a round
	private JLabel lblLivesOrSpectator  = new JLabel("Spectator");		// Initialize a label to display the player's role (spectator or their lives as players)
	private boolean wonGame = false;									// Initialize a boolean to flag if someone has won the game
	private int numOfPlayers = 0; 										// Initialize an integer to store the number of players that entered the game
		
	public GameScreen(String ipAddress_t, String username_t) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	GameScreen (Constructor)
	//
	// Method parameters	:	ipAddress_t, username_t
	//
	// Method return		:	void
	//
	// Synopsis				:   This method creates the user interface items, such as labels, buttons and panels.
	//
	// References			:   Oracle (2022) Lesson: Performing Custom Painting.
	//							https://docs.oracle.com/javase/tutorial/uiswing/painting/index.html
	//							GeeksForGeeks (2023) Super Keyword in Java. https://www.geeksforgeeks.org/super-keyword/	
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Game Screen
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		setResizable(false);
		username = username_t;																// set the username equal to the username gotten from the previous screen
		ipAddress = ipAddress_t;															// set the ip address equal to the ip address gotten from the previous screen
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				status = "Offline";															// if the user closes the application, set their status to offline
				try {
					playerConnection = new PlayerConnection(ipAddress);						// instantiate a player connection
					String infoUpdate = username+","+status;								// create a string to save the username and their updated status
					playerConnection.sendInformationToServer(infoUpdate);					// send the new information to the server 
					JOptionPane.showMessageDialog(contentPane, "Closing the game.");		// display a closing message
				} catch (IOException e1) {
					e1.printStackTrace();													// if an exception is triggered, print the stack trace
				}
			}
		});
		
		tickTock.start();																	// start the timer 
		setTitle("GET THE FLAG!");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 650);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);		
		
		lblAnnouncement.setVisible(false);
		lblAnnouncement.setHorizontalAlignment(SwingConstants.CENTER);
		lblAnnouncement.setForeground(Color.WHITE);
		lblAnnouncement.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblAnnouncement.setBounds(225, 200, 520, 162);
		contentPane.add(lblAnnouncement);

		panel = new JPanel()
		 { 
		    @Override
		    protected void paintComponent(Graphics g) {										// override the paint component method of the game panel
		        super.paintComponent(g);													// call the paint component of the parent object 
		        drawPlayers((Graphics2D) g);												// call the draw players method and pass the graphics component as a parameter
		    }
		};
		panel.setOpaque(false);
		panel.setBorder(new LineBorder(new Color(176, 196, 222)));
		panel.setBounds(38, 98, 900, 400);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JPanel panelLives = new JPanel() { 
		    @Override
		    protected void paintComponent(Graphics g) {										// override the paint component method of the lives panel
		        super.paintComponent(g);													// call the paint component of the parent object
		        drawLives((Graphics2D) g, playerLives);										// call the draw lives method and pass the graphics component 
		        																			// and player's lives as parameters 
		    }
		};
		panelLives.setOpaque(false);
		panelLives.setBounds(381, 518, 286, 49);
		panelLives.setLayout(null);
		contentPane.add(panelLives);
		
		
		JLabel lblGameField = new JLabel("");
		lblGameField.setIcon(new ImageIcon(GameScreen.class.getResource("/Media/GameField.png")));
		lblGameField.setBounds(38, 98, 900, 400);
		contentPane.add(lblGameField);
		
		lblScoreTeam1 = new JLabel("0");
		lblScoreTeam1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblScoreTeam1.setHorizontalAlignment(SwingConstants.CENTER);
		lblScoreTeam1.setForeground(Color.WHITE);
		lblScoreTeam1.setBorder(new LineBorder(Color.CYAN, 3));
		lblScoreTeam1.setBounds(444, 57, 45, 45);
		contentPane.add(lblScoreTeam1);
		
		lblScoreTeam2 = new JLabel("0");
		lblScoreTeam2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblScoreTeam2.setHorizontalAlignment(SwingConstants.CENTER);
		lblScoreTeam2.setForeground(Color.WHITE);
		lblScoreTeam2.setBorder(new LineBorder(Color.CYAN, 3));
		lblScoreTeam2.setBounds(487, 57, 45, 45);
		contentPane.add(lblScoreTeam2);
		
		JLabel lblScore = new JLabel("SCORE");
		lblScore.setHorizontalAlignment(SwingConstants.CENTER);
		lblScore.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblScore.setForeground(new Color(102, 153, 255));
		lblScore.setBounds(443, 22, 89, 24);
		contentPane.add(lblScore);
		
		JLabel lblPlayer = new JLabel("PLAYER ID:");
		lblPlayer.setHorizontalAlignment(SwingConstants.CENTER);
		lblPlayer.setForeground(new Color(102, 153, 255));
		lblPlayer.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPlayer.setBounds(38, 28, 89, 24);
		contentPane.add(lblPlayer);
		
		JLabel lblPlayerID = new JLabel(username);
		lblPlayerID.setHorizontalAlignment(SwingConstants.CENTER);
		lblPlayerID.setForeground(new Color(176, 196, 222));
		lblPlayerID.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblPlayerID.setBounds(137, 28, 89, 24);
		contentPane.add(lblPlayerID);
		
		lblLivesOrSpectator.setOpaque(true);
		lblLivesOrSpectator.setBackground(Color.BLACK);
		lblLivesOrSpectator.setHorizontalAlignment(SwingConstants.CENTER);
		lblLivesOrSpectator.setForeground(new Color(102, 153, 255));
		lblLivesOrSpectator.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblLivesOrSpectator.setBounds(381, 566, 212, 40);
		contentPane.add(lblLivesOrSpectator);
		
		JLabel lblLife1 = new JLabel("");
		lblLife1.setOpaque(true);
		lblLife1.setBackground(Color.GRAY);
		lblLife1.setBounds(383, 519, 12, 35);
		contentPane.add(lblLife1);
		
		JLabel lblLife2 = new JLabel("");
		lblLife2.setOpaque(true);
		lblLife2.setBackground(Color.GRAY);
		lblLife2.setBounds(405, 519, 12, 35);
		contentPane.add(lblLife2);
		
		JLabel lblLife3 = new JLabel("");
		lblLife3.setOpaque(true);
		lblLife3.setBackground(Color.GRAY);
		lblLife3.setBounds(427, 519, 12, 35);
		contentPane.add(lblLife3);
		
		JLabel lblLife4 = new JLabel("");
		lblLife4.setOpaque(true);
		lblLife4.setBackground(Color.GRAY);
		lblLife4.setBounds(449, 519, 12, 35);
		contentPane.add(lblLife4);
		
		JLabel lblLife5 = new JLabel("");
		lblLife5.setOpaque(true);
		lblLife5.setBackground(Color.GRAY);
		lblLife5.setBounds(471, 519, 12, 35);
		contentPane.add(lblLife5);
		
		JLabel lblLife6 = new JLabel("");
		lblLife6.setOpaque(true);
		lblLife6.setBackground(Color.GRAY);
		lblLife6.setBounds(493, 519, 12, 35);
		contentPane.add(lblLife6);
		
		JLabel lblLife7 = new JLabel("");
		lblLife7.setOpaque(true);
		lblLife7.setBackground(Color.GRAY);
		lblLife7.setBounds(515, 519, 12, 35);
		contentPane.add(lblLife7);
		
		JLabel lblLife8 = new JLabel("");
		lblLife8.setOpaque(true);
		lblLife8.setBackground(Color.GRAY);
		lblLife8.setBounds(537, 519, 12, 35);
		contentPane.add(lblLife8);
		
		JLabel lblLife9 = new JLabel("");
		lblLife9.setOpaque(true);
		lblLife9.setBackground(Color.GRAY);
		lblLife9.setBounds(559, 519, 12, 35);
		contentPane.add(lblLife9);
		
		JLabel lblLife10 = new JLabel("");
		lblLife10.setOpaque(true);
		lblLife10.setBackground(Color.GRAY);
		lblLife10.setBounds(581, 519, 12, 35);
		contentPane.add(lblLife10);
		
	
		lblTeam = new JLabel("Team ");
		lblTeam.setHorizontalAlignment(SwingConstants.CENTER);
		lblTeam.setForeground(new Color(176, 196, 222));
		lblTeam.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblTeam.setBounds(849, 22, 89, 24);
		contentPane.add(lblTeam);
		
		JLabel lblBackground = new JLabel("");
		lblBackground.setIcon(new ImageIcon(GameScreen.class.getResource("/Media/Background.png")));
		lblBackground.setBounds(0, 0, 984, 611);
		contentPane.add(lblBackground);
		
		setFocusable(true);																	// set focusable to true
	    addKeyListener(this);																// add a key listener to this screen				
	    setVisible(true);																	// set the screen as visible
	    requestFocusInWindow();   
	}
	
	public void setNumOfPlayers(int num) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	setNumOfPlayers
	//
	// Method parameters	:	num
	//
	// Method return		:	void
	//
	// Synopsis				:   This method sets the number of players that entered the game.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Set Number Of Players
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		numOfPlayers = num;						// set the number of players equal to the number passed
	}
	
	public void setIpAddress(String ipAddress_t) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	setIpAddress
	//
	// Method parameters	:	ipAddress_t
	//
	// Method return		:	void
	//
	// Synopsis				:   This method sets the IpAddress of the server.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Set IpAddress
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.ipAddress = ipAddress_t;			// set the IpAddress equal to the string passed
	}
	
	public void setUsername(String username_t) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	setUsername
	//
	// Method parameters	:	username_t
	//
	// Method return		:	void
	//
	// Synopsis				:   This method sets the username of the player.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Set Username
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.username = username_t;				// set the username equal to the string passed
	}
	
	public Player getPlayer(String username) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	GameScreen (Constructor)
	//
	// Method parameters	:	ipAddress_t, username_t
	//
	// Method return		:	void
	//
	// Synopsis				:   This method creates the user interface items, such as labels, buttons and panels.
	//
	// References			:   Oracle (2022) Lesson: Performing Custom Painting.
	//							https://docs.oracle.com/javase/tutorial/uiswing/painting/index.html
	//							GeeksForGeeks (2023) Super Keyword in Java. https://www.geeksforgeeks.org/super-keyword/	
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Game Screen
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		for(Player playerInGame : players)
		{
			if(playerInGame.getUsername().equals(username)) 
				return playerInGame;
		}
		return null;
	}
	
	public void checkPlayers() {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	checkPlayers
	//
	// Method parameters	:	none
	//
	// Method return		:	void
	//
	// Synopsis				:   This method checks if the users are players or spectators.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Check Players
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=	
		for(Player player : players)
		{
			if(player.getUsername().equals(username)) {
				lblLivesOrSpectator.setText("Lives");						// if the user is in the players list, display the lives text
				return;														// return to where the method was called
			}
		}
		lblLivesOrSpectator.setText("Spectator");							// if the user is not on the players list, display the spectator text
		return;																// return to where the method was called
	}
	
	public void drawPlayers(Graphics2D g) {  				
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	drawPlayers
	//
	// Method parameters	:	Graphics2D g
	//
	// Method return		:	void
	//
	// Synopsis				:   This method is used to draw the players on the game screen.
	//
	// References			:   Oracle (2022) Lesson: Performing Custom Painting.
	//							https://docs.oracle.com/javase/tutorial/uiswing/painting/index.html
	//							https://docs.oracle.com/javase/tutorial/2d/geometry/strokeandfill.html
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Draw Players
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		int radius;													// declare an integer to store the player's radius
		int diameter;												// declare an integer to store the player's diameter
		int x;														// declare an integer to store the player's position on x
		int y;														// declare an integer to store the player's position on x
		
		g.setStroke(new BasicStroke(5)); 							// set the stroke thickness of the area delimiters to 5
		
		for(Player player : players)
		{
	       radius = 0; 												// set the initial radius to zero
	       if(player.getStatus() == Player.PlayerStatus.ATTACKING)	
	        	radius = radiusAttack;								// update the radius to the player's attack radius
	       else
	    	   radius = 15;											// or else set it to 15
	        diameter = radius * 2;									// set the player's diameter
	        Point currentPosition = player.getPosition();			// set the player's position
			x = currentPosition.x - radius;							// update the position so that its at the center of the object
	        y = currentPosition.y - radius;							// update the position so that its at the center of the object

	        if(player.getStatus() != Player.PlayerStatus.ATTACKING && player.getStatus() != Player.PlayerStatus.DAMAGE)
	        {
	        	if(player.getTeam() == 1)
	 	        	g.setColor(Color.RED); 										// if the player is in team 1, set the painting color to red
	 	        else 
	 	        	g.setColor(Color.GREEN); 									// if they are in team 2, set the painting color to green
	        }
	        else  if(player.getStatus() == Player.PlayerStatus.ATTACKING || player.getStatus() == Player.PlayerStatus.DAMAGE)
	        	g.setColor(Color.white); 										// if they are attacking, set their color to white
	        
	        g.fillOval(x, y, diameter, diameter);								// fill the oval shape of the player
	        if(player.isFlag())
	        {
	        	g.setColor(Color.YELLOW);										// if the player is the flag, set the painting color to yellow
		        g.drawOval(x, y, diameter-1, diameter-1);						// draw a yellow border to show they are the flag
	        }
	        
	        if(player.getUsername().equals(username)) {

	        	int smallDiameter = diameter / 4;								// calculate a smaller diameter for the dot that indicate's the client's player
	            int centerX = x + radius; 										// Center X of the larger circle
	            int centerY = y + radius; 										// Center Y of the larger circle

	            int smallX = centerX - smallDiameter / 2; 						// Adjusted X for the small circle
	            int smallY = centerY - smallDiameter / 2; 						// Adjusted Y for the small circle

	            g.setColor(Color.BLUE);											// set the painting color to blue
	            g.fillOval(smallX, smallY, smallDiameter, smallDiameter);		// draw the visual aid circle    
        	}
		}
		checkPlayers();															// check if the client is a player or spectator 
		panel.repaint();														// repaint the game area panel
    } 
	
	@SuppressWarnings({ "serial", "serial" })
	public void actionPerformed(ActionEvent e) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	actionPerformed
	//
	// Method parameters	:	ActionEvent e
	//
	// Method return		:	void
	//
	// Synopsis				:   This method is managed by the timer event. All the automatic updates with the server are done here.
	//
	// References			:   none			
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-02-20		V. Arias,               Action Performed (Timer controlled)
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=		
		if(counterTicks > 0)
    		counterTicks--;														// if counter ticks is over zero, decrease by one
		
		currentPlayer = getPlayer(username);									// set the current player equal to the player with the client's username
																				// from the players list
		if(currentPlayer != null && !endRound)
		{
			if(counterTicks < 12 && counterTicks > 9 && currentPlayer.getStatus() == Player.PlayerStatus.DAMAGE)
			{
				currentPlayer.setStatus(Player.PlayerStatus.DEFENSE);			// set the status of the current player to defense
			}
			else if(counterTicks <= 0 )
			{
       		 	currentPlayer.setStatus(Player.PlayerStatus.DEFENSE);			// set the status of the current player to defense
       		 	updateServer(currentPlayer, 1);									// call the update server method and send the current player
			}
			playerLives = currentPlayer.getLives();								// set the player's lives to the current player's lives 
		}
		
		if(lblAnnouncement.isVisible() && counterTicks > 0) {
        		counterTicks--;													// if the announcement label is visible decrease the counter 
        		if(counterTicks <= 0) {
        			lblAnnouncement.setVisible(false);							// if the counter runs out (is less than zero) hide the label
        			
        			if(scoreTeam1 < 2 && scoreTeam2 <2 ) {
        				startNewRound();										// if none of the teams have won, start a new round
        			}
        			else if(scoreTeam1 == 2) {
        				wonGame = true;											// if team 1 has reached 2 points, set won game to true
        				lblAnnouncement.setText("Team 1 Won the game");			// set the text of the label announcing the winner
        				lblAnnouncement.setVisible(true);						// set the announcement label to visible
        			}
        			else if(scoreTeam2 == 2) {
        				wonGame = true;											// if team 2 has reached 2 points, set won game to true
        				lblAnnouncement.setText("Team 2 Won the game");			// set the text of the label announcing the winner
        				lblAnnouncement.setVisible(true);						// set the announcement label to visible
        			}
        		}
		}
		if(wonGame) {
			counterTicksResult--;												// if a team won the game, decrease the timer of the message showing
			if(counterTicksResult <= 0) {
				goToLobby();													// when the timer is over, go back to the lobby
			}
		}
		checkRoundWinner();														// check if a team has won the round
		
		if (numOfPlayers != players.size() && players.size() > 0 && wonGame == false) {	
			JOptionPane.showMessageDialog(contentPane, "Number of players not valid, returning to Game Lobby."); // if a player leaves the game, pop-up a waning message.
			goToLobby();																						 // go back to the lobby
		}
		
		paintScreen();															// repaint the game screen
	}

	@Override
	public void keyPressed(KeyEvent e) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	keyPressed
	//
	// Method parameters	:	e
	//
	// Method return		:	void
	//
	// Synopsis				:   This method handles the key pressed events.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Key Pressed
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		if(!lblAnnouncement.isVisible())
		{
			int key = e.getKeyCode();											// declare a variable and store the key code
			currentPlayer = getPlayer(username);								// set the current player to the player with the same username as the client
			
			if(currentPlayer !=null && currentPlayer.getStatus()!=Player.PlayerStatus.DEAD)
			{
				int radius = currentPlayer.getRadius();							// declare and store the current player's radius
	            Point currentPosition = currentPlayer.getPosition();			// get the current player's position and store it 
	            
	            switch(key) 
	            { 
	            	case KeyEvent.VK_A:
	                	//if (isFlagNearby(currentPlayer)) 		
	            		if(checkSurroundings(currentPlayer, 3))
	            		{ 
	                		endRound = true;									// if the key pressed is A, and they are close to a flag, end the round
	                		checkRoundWinner();									// check who has won the round
	                    }
	                	break;
	                case KeyEvent.VK_UP: 										// Arrow Up
	                	if(currentPosition.y >=45-radius )
	                		currentPosition.y -= 10; 							// Move up
	                    break;
	                case KeyEvent.VK_DOWN: 										// Arrow Down
	                	if(currentPosition.y <=390-radius )
	                		currentPosition.y += 10; 							// Move down
	                    break;
	                case KeyEvent.VK_LEFT: 										// Arrow Left
	                	if(currentPosition.x >=105-radius )
	                		currentPosition.x -= 10; 							// Move left
	                    break;
	                case KeyEvent.VK_RIGHT: 									// Arrow Right
	                	if(currentPosition.x <=830-radius )
	                		currentPosition.x += 10; 							// Move right
	                    break;
	                case KeyEvent.VK_SPACE:
	                	if (currentPlayer.getStatus() == Player.PlayerStatus.DEFENSE && checkSurroundings(currentPlayer, 1)) 					
                		{ 	
	                		counterTicks = 20;												// reset the counter ticks
                			currentPlayer.setStatus(Player.PlayerStatus.ATTACKING);			// change the player status to attacking
                			updateServer(currentPlayer, 1);									// update the server data
                        }
	            }
	            if(!checkSurroundings(currentPlayer, 2))						
	            	updateServer(currentPlayer, 1); 										// Update player position on server side
			}
		    paintScreen();														// repaint the game screen
		}		    
	}
	
	@Override
	public void keyReleased(KeyEvent e) {
		// Do nothing, linked to the key pressed event override method
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// Do nothing, linked to the key pressed event override method
	}
		
	public void updateServer(Player playerToUpdate, int option) {  
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	updateServer
	//
	// Method parameters	:	playerToUpdate, option
	//
	// Method return		:	void
	//
	// Synopsis				:   This method updates the server information.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Update Server
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		if(playerToUpdate != null)
		{
			String playerString = null;										// declare a string to handle the player information
			if(option == 1)
			{
				String playerStatus = playerToUpdate.getStatus().name();	// declare a string to store the player status
				JSONObject playerJson = 									// Create JSon object to send to the server
						new JSONObject("{ \"username\" : \"" + playerToUpdate.getUsername() + "\" , \"team\" : \"" + playerToUpdate.getTeam() +"\"  ,  \"positionX\" : \"" + playerToUpdate.getPosition().x+ "\" ,  \"positionY\" : \"" + playerToUpdate.getPosition().y + "\"  , "
								+ "						\"lives\" : \"" + playerToUpdate.getLives() +  "\" ,  \"isFlag\" : \"" + playerToUpdate.isFlag() + "\" , \"radius\" : \"" + playerToUpdate.getRadius() +"\" , \"status\":\"" + playerStatus+ "\"}");
				playerString = String.valueOf(playerJson);					// JSon object stored in a string variable
				PlayerConnection playerConnectionObj;						// Declare a player connection object
				try {
					playerConnectionObj = new PlayerConnection(ipAddress);			// Instantiate the player connection object
					playerConnectionObj.sendInformationToServer(playerString);		// Send the player string to the server
					players = playerConnectionObj.getPlayers();						// get the players and store the in the players list
					for(Player playersList: players)
					{
						if(playersList.equals(currentPlayer))
						{
							currentPlayer.setLives(playersList.getLives());			// set the lives of the current player 
							playerLives = currentPlayer.getLives();					// set the player variables to the lives of the current player
						}
					}
				} catch (IOException e1) {
					e1.printStackTrace();											// if there is an error, print the stack trace
				}
			}
		}
	}
				
	public void updateLives(Player playerAttacked) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	updateLives
	//
	// Method parameters	:	playerAttacked
	//
	// Method return		:	void
	//
	// Synopsis				:   This method updates the lives of the player.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Update Lives
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		if(playerAttacked != null)
		{
            JSONObject playerJson = 									// Create JSon object to send to the server
					new JSONObject("{ \"username\" : \"" + playerAttacked.getUsername() + "\" , \"lives\" : \"" + playerAttacked.getLives() + "\"}");
			String playerString = String.valueOf(playerJson);			// JSon object stored in a string variable
			PlayerConnection playerConnectionObj;						// declare a player connection object
			
			try {
				playerConnectionObj = new PlayerConnection(ipAddress);		// instantiate the player connection object
				playerConnectionObj.sendInformationToServer(playerString);	// send the updated player information to the server
				players = playerConnectionObj.getPlayers();					// get the players from the server
	
			} catch (IOException e1) {
				e1.printStackTrace();										// if there is an error, print the stack trace
			}
		}
	}
		
	public boolean checkSurroundings(Player player, int option) {   
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	checkSurroundings
	//
	// Method parameters	:	player, option
	//
	// Method return		:	boolean
	//
	// Synopsis				:   This method checks the surroundings of the player.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Check Surroundings
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	    Point playerPos = player.getPosition();						// declare the player position variable and store the current position
	    short team = player.getTeam();								// get the team the player is a part of and store it in a short
	    int diameter = player.getRadius() * 2;						// get the diameter of the player
	    int enemyDiameter = diameter + 3;							// calculate and store the enemy diameter
	    int collisionDiameter = diameter - 2;						// calculate and store the collision diameter of the player
	    
	    for (Player otherPlayer : players) {
	        if (player != otherPlayer) {
		        int xDistance = playerPos.x - otherPlayer.getPosition().x;				// calculate and store the distance between two players in x
		        int yDistance = playerPos.y - otherPlayer.getPosition().y;				// and in y
		        int distanceSquared = xDistance * xDistance + yDistance * yDistance;	// then calculate the distance squared
		   
		        if (option == 1) {														// enemy nearby
		            if (!otherPlayer.isFlag() && team != otherPlayer.getTeam() && distanceSquared <= enemyDiameter * enemyDiameter) {
		                otherPlayer.setLives((short) (otherPlayer.getLives() - 1));		// subtract on life from the other player
		                otherPlayer.setStatus(Player.PlayerStatus.DAMAGE);				// change the player status to damage																								//*******************************************
		                updateServer(otherPlayer, 1);									// update the server information
		                return true;
		            }
		        } 
		        else if (option == 2)													// there was a collision
		        {
		        	if (distanceSquared <= collisionDiameter * collisionDiameter) 
			            return true;													// if there was a collision, return true
		        }
		        else if (option == 3)													// flag nearby
	        	{
	        		if(otherPlayer.isFlag() && team != otherPlayer.getTeam() && distanceSquared <= enemyDiameter * enemyDiameter)
	        		{
	        			currentPlayer.setStatus(Player.PlayerStatus.WIN); 				// change the current player status to win
	        			updateServer(otherPlayer, 1); 									// update the other player data in the server
	        			contentPane.repaint();											// repaint the content pane
                		updateServer(currentPlayer, 1); 								// update the server information of the current player
	        			return true;													// return true
	        		}
	        	}
	        }//end if to avoid self check
	    }//end for
	    
	    return false;
	}
		
	public void checkRoundWinner() {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	checkRoundWinner
	//
	// Method parameters	:	none
	//
	// Method return		:	void
	//
	// Synopsis				:   This method checks who won the round.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Check Round Winner
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		for(int i=0;i<players.size() ;i++)
	    {	
			if(players.get(i).getStatus().equals(Player.PlayerStatus.WIN) && !lblAnnouncement.isVisible()) {
				if(players.get(i).getTeam() == 1) {
					scoreTeam1 += 1;									// if team 1 won, increase the score by one
					endRound = false;									// set the end round boolean to false
					lblScoreTeam1.setText(String.valueOf(scoreTeam1));	// set the text of the score label
				}	
				if(players.get(i).getTeam() == 2) {
					scoreTeam2 += 1;									// if team 2 won, increase the score by one
					endRound = false;									// set the end round boolean to false
					lblScoreTeam2.setText(String.valueOf(scoreTeam2));	// set the text of the score label
				}
				lblAnnouncement.setText("Team " +players.get(i).getTeam() + " Won the round");	// Set the text of the announcement label
				lblAnnouncement.setVisible(true);						// set the announcement label as visible
				counterTicks = 120;										// reset the counter ticks 
				}	
		}
	}
		
	public void startNewRound() {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	startNewRound
	//
	// Method parameters	:	none
	//
	// Method return		:	void
	//
	// Synopsis				:   This method does the setup to start a new round.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Start New Round
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		PlayerConnection playerConnectionObj;							// Declare the player connection object
		try {
			playerConnectionObj = new PlayerConnection(ipAddress);		// instantiate the player connection object
			playerConnectionObj.sendInformationToServer("res");			// send the "res" message to the server
			players = playerConnectionObj.getPlayers();					// get the updated list of players
		} catch (IOException e1) {
			e1.printStackTrace();										// if there is an error, print the stack trace
		}
		panel.repaint();												// repaint the content game panel
	}
	
	public void goToLobby() {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	goToLobby
	//
	// Method parameters	:	none
	//
	// Method return		:	void
	//
	// Synopsis				:   This method takes the players back to the lobby and closes the game screen.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Go To Lobby
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		deletePlayers();											// delete the players 
		dispose();													// dispose of the game screen
		tickTock.stop();											// stop the timer
		GameLobby gameLobby = new GameLobby();						// instantiate a new game lobby screen
		gameLobby.SetPlayerID(username, ipAddress, "Online");		// set the player ID with their username, ipAddress and status
		gameLobby.setGameInProgress(false);							// set the game in progress boolean to false
		gameLobby.setScreenOpen(false);								// set the screen open variable to false
		gameLobby.setVisible(true);									// set the game lobby screen to visible
	}
		
	public void deletePlayers() {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	deletePlayers
	//
	// Method parameters	:	none
	//
	// Method return		:	void
	//
	// Synopsis				:   This method deletes the players from the server.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Delete Players
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		PlayerConnection playerConnectionObj;								// Declare the player connection object
		try {
			playerConnectionObj = new PlayerConnection(ipAddress);			// instantiate the player connection object
			playerConnectionObj.sendInformationToServer("del");				// send the "del" message to the server
			players = playerConnectionObj.getPlayers();						// get the updated list of players
		} catch (IOException e1) {
			e1.printStackTrace();											// if there is an error, print the stack trace
		}
	} 
	
	public void drawLives(Graphics2D g, int lives) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	drawLives
	//
	// Method parameters	:	g, lives
	//
	// Method return		:	void
	//
	// Synopsis				:   This method draws the lives graphics.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Draw Lives
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		int startX = 0; 					// starting x position for the first label
        int labelWidth = 12; 				// width of each label
        int distanceX = 22; 				// distance between each label
        int labelHeight = 35; 				// height of each label
        int x;								// declare an integer to store the x position
        int y;								// declare an integer to store the y position

        g.setColor(Color.YELLOW); 			// Set the color
        
        if(lives > 0) {
        for (int i = 0; i < lives; i++) {
            x = startX + i * distanceX;		// calculate the x values
            y = 0;							// set the y value to zero
            g.fillRect(x, y, labelWidth, labelHeight); // Draw a rectangle for each life
        }
        }
	}
		
	public void paintScreen() {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	paintScreen
	//
	// Method parameters	:	none
	//
	// Method return		:	void
	//
	// Synopsis				:   This method creates the user interface items, such as labels, buttons and panels.
	//
	// References			:   none
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Paint Screen
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		PlayerConnection playerConnectionObj;										// Declare the player connection object
		try {
			playerConnectionObj = new PlayerConnection(ipAddress);					// instantiate the player connection object
			playerConnectionObj.sendInformationToServer("getPos");					// send the "getPos" message to the server
			players = playerConnectionObj.getPlayers();								// get the updated list of players
			
			if(firstSetup) {
				for(Player player : players)
				{
					if(player.getUsername().equals(username)) {
						lblTeam.setText(lblTeam.getText() + player.getTeam());		// set the text of the team
						playerLives = player.getLives();							// get the player lives 
					}
					
				}
				firstSetup = false;													// set the first setup variable to false
			}
		} catch (IOException e1) {
			e1.printStackTrace();													// if there is an error, print the stack trace
		}
		contentPane.repaint();														// repaint the content pane
	}	
}