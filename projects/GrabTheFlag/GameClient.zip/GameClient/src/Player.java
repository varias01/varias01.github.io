import java.awt.Point;

public class Player {
																														//Define the attributes of the class player	
	public enum PlayerStatus {																							//Declarate a playerStatus enum
		DEFENSE, 																										//to manage the different player states	
		ATTACKING, 
		DAMAGE,
		DEAD,
		WIN
		}														
	private String username;                          																   //Declarate player username					
	private boolean isFlag;																							   //Declarate isFlag variable to check if the player has the flag		
	private short lives;																							   //Declarate data member to store the lives of the player	 
	private Point position;																							   //Declarate data member position			
	private short team;																								   //Declarate team variable	
	private short radius;																							   //Declarate radius variable		
	private PlayerStatus status;																					   //Declarate playerStatus based on playerenum type	
	
	
	public Player() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	Player()
		//
		// Method parameters	:	none
		//
		// Method return		:	void
		//
		// Synopsis				:   This method is the constructor of the player classs. 
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
																														//Create an empty player	
		username = "";                          																		//Set the username empty
		isFlag = false;																									//Set isFlag to false	
		lives = 0;																										//Set lives at 0
		position = null;																								//Set position null	
		team = 0;																										//Set team to 0	
		radius = 0;																										//Set radius to 0
		status = PlayerStatus.DEFENSE;																					//Set the initial status to Defense	
	}
	
	public String getUsername() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	getUsername()
				//
				// Method parameters	:	none
				//
				// Method return		:	String
				//
				// Synopsis				:   This method allows to get the player username. 
				//
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-09		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return username;																								//Return player username	
	}
	public void setUsername(String userName) {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	setUsername(String userName)
		//
		// Method parameters	:	String userName
		//
		// Method return		:	void
		//
		// Synopsis				:   This method allows to set the player username. 
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.username = userName;																						//Set the username
	}
	public boolean isFlag() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	isFlag()
				//
				// Method parameters	:	none
				//
				// Method return		:	boolean
				//
				// Synopsis				:   This method allows to get the boolean value if the player has the flag. 
				//
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-09		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return isFlag;																									//Return the value
	}
	public void setFlag(boolean isFlag) {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	setFlag(boolean isFlag)
		//
		// Method parameters	:	boolean isFlag
		//
		// Method return		:	void
		//
		// Synopsis				:   This method allows to set the boolean value depends if the player has the flag. 
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.isFlag = isFlag;																						 //Set the flag value
	}
	public short getLives() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	getLives()
				//
				// Method parameters	:	none
				//
				// Method return		:	short
				//
				// Synopsis				:   This method allows to get the amount of lives of the player. 
				//
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-09		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return lives;																								//Return the lives value
	}
	public void setLives(short lives) {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	setLives(short lives)
		//
		// Method parameters	:	none
		//
		// Method return		:	short
		//
		// Synopsis				:   This method allows to set the amount of lives of the player. 
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.lives = lives;																							//Set the lives value	
	}
	
	public Point getPosition() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	getPosition()
				//
				// Method parameters	:	none
				//
				// Method return		:	Point
				//
				// Synopsis				:   This method allows to get the coordinates of the player.
				//
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-09		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return position;																								//Return the position
	}

	public void setPosition(Point position) {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	setPosition(Point position)
		//
		// Method parameters	:	Point position
		//
		// Method return		:	void
		//
		// Synopsis				:   This method allows to set the coordinates of the player.
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.position = position;																						//Set the player position	
	}

	public short getTeam() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	getTeam()
				//
				// Method parameters	:	none
				//
				// Method return		:	short
				//
				// Synopsis				:   This method allows to get the team number
				//
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-09		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return team;																									//Return the team number
	}

	public void setTeam(short team) {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	setTeam(short team)
		//
		// Method parameters	:	short team
		//
		// Method return		:	void
		//
		// Synopsis				:   This method allows to set the team number
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.team = team;																							//Set team number
	}

	public int getRadius() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	getRadius()
		//
		// Method parameters	:	none
		//
		// Method return		:	int
		//
		// Synopsis				:   This method allows to get the value of the radius of the circle player
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return radius;																							//Return radius value
	}

	public void setRadius(short radio) {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	setRadius(short radio)
				//
				// Method parameters	:	short radio
				//
				// Method return		:	void
				//
				// Synopsis				:   This method allows to set the value of the radius of the circle player
				//
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-09		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.radius = radio;																				//Set radio value
	}

    public PlayerStatus getStatus() {
    	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	getStatus()
		//
		// Method parameters	:	none
		//
		// Method return		:	PlayerStatus
		//
		// Synopsis				:   This method allows to get the player status
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return status;																						//Return player status value
	}

	public void setStatus(PlayerStatus status) {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	setStatus(PlayerStatus status)
				//
				// Method parameters	:	none
				//
				// Method return		:	PlayerStatus
				//
				// Synopsis				:   This method allows to get the player status
				//
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-09		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.status = status;																			//Set the player status
	}
	
	public Player createPlayer(String username, boolean isFlag, short lives, Point position, short team, short radius, String status)
	{
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	createPlayer(String username, boolean isFlag, short lives, Point position, short team, short radius, String status)
		//
		// Method parameters	:	String username, boolean isFlag, short lives, Point position, short team, short radius, String status
		//
		// Method return		:	Player
		//
		// Synopsis				:   This method allows to create a player
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		this.username = username;                         													//Set username value	
		this.isFlag = isFlag;																				//Set isFlag
		this.lives = lives;																					//Set the amount of lives	
		this.position = position;																			//Set position		
		this.team = team;																					//Set team number
		this.radius = radius;																				//Set radius
		this.status = PlayerStatus.valueOf(status);															//Set player status
		return this;																						//Return the player
	}

}
