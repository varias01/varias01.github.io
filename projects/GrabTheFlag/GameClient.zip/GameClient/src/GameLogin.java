import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ImageIcon;

public class GameLogin extends JFrame {

	private JPanel contentPane;																							//Declarate content Panel
	private JTextField textFieldIPAddress;																				//Declarate the ipAddress text field
	private JTextField textFieldPlayerID;																				//Declarate the player id
	private PlayerConnection playerConnection;																			//Declarate a playerConnection object	
	private GameLobby lobby;																							//Declarate a GameLobby object

	public static void main(String[] args) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	main(String[] args)
	//
	// Method parameters	:	port
	//
	// Method return		:	void
	//
	// Synopsis				:   This method runs the game login screen
	//
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-09		V. Arias,               
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GameLogin frame = new GameLogin();																//Define a gameLogin object							
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public GameLogin() {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	GameLogin() 
	//
	// Method parameters	:	none
	//
	// Method return		:	void
	//
	// Synopsis				:   This method is a constructor of the game login interface
	//
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-09		V. Arias,               
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 340);
		setTitle("Game Login");
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIPAddress = new JLabel("IP ADDRESS: ");
		lblIPAddress.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblIPAddress.setForeground(new Color(102, 153, 255));
		lblIPAddress.setBounds(73, 121, 112, 14);
		contentPane.add(lblIPAddress);
		
		JLabel lblPlayerID = new JLabel("PLAYER ID");
		lblPlayerID.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblPlayerID.setForeground(new Color(102, 153, 255));
		lblPlayerID.setBounds(73, 167, 106, 14);
		contentPane.add(lblPlayerID);
		
		JLabel lblGameTitle = new JLabel("Grab The Flag!");
		lblGameTitle.setFont(new Font("Tahoma", Font.BOLD, 24));
		lblGameTitle.setForeground(Color.CYAN);
		lblGameTitle.setHorizontalAlignment(SwingConstants.CENTER);
		lblGameTitle.setBounds(151, 25, 223, 85);
		contentPane.add(lblGameTitle);
		
		JLabel lblInstructions = new JLabel("Please enter the server IP Address and a player ID with letters ");
		lblInstructions.setHorizontalAlignment(SwingConstants.CENTER);
		lblInstructions.setForeground(new Color(102, 153, 255));
		lblInstructions.setBounds(10, 258, 414, 14);
		contentPane.add(lblInstructions);
		
		JLabel lblInstructionsContinued = new JLabel("and/or numbers that contains from 3 to 6 characters.");
		lblInstructionsContinued.setHorizontalAlignment(SwingConstants.CENTER);
		lblInstructionsContinued.setForeground(new Color(102, 153, 255));
		lblInstructionsContinued.setBounds(10, 276, 414, 14);
		contentPane.add(lblInstructionsContinued);
		
		JLabel lblGameLogo = new JLabel("");
		lblGameLogo.setIcon(new ImageIcon(GameLogin.class.getResource("/Media/Logo.png")));
		lblGameLogo.setBounds(78, 26, 70, 70);
		contentPane.add(lblGameLogo);
		
		textFieldIPAddress = new JTextField();
		textFieldIPAddress.setFont(new Font("Tahoma", Font.BOLD, 12));
		textFieldIPAddress.setBackground(Color.LIGHT_GRAY);
		textFieldIPAddress.setForeground(Color.BLACK);
		textFieldIPAddress.setBounds(189, 118, 169, 20);
		contentPane.add(textFieldIPAddress);
		textFieldIPAddress.setColumns(10);
		
		textFieldPlayerID = new JTextField();
		textFieldPlayerID.setFont(new Font("Tahoma", Font.BOLD, 12));
		textFieldPlayerID.setForeground(Color.BLACK);
		textFieldPlayerID.setBackground(Color.LIGHT_GRAY);
		textFieldPlayerID.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER)
					enterAction();
			}
		});
		textFieldPlayerID.setBounds(189, 164, 169, 20);
		contentPane.add(textFieldPlayerID);
		textFieldPlayerID.setColumns(10);
		
		JButton btnEnter = new JButton("ENTER LOBBY");
		btnEnter.setFocusPainted(false);
		btnEnter.setForeground(new Color(176, 196, 222));
		btnEnter.setBorder(new LineBorder(new Color(0, 0, 255), 3));
		btnEnter.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnEnter.setBackground(Color.BLACK);
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {																	//When user clicked enter button	
				enterAction();																								//Call the enterAction method
			}
		});
		btnEnter.setBounds(158, 213, 106, 23);
		contentPane.add(btnEnter);			
	}
	
	public boolean isValidIP(String input, String pattern) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	isValidIP(String input, String pattern)
	//
	// Method parameters	:	String input, String pattern
	//
	// Method return		:	boolean
	//
	// Synopsis				:   This method check if the ip is valid according to the pattern
	//
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-09		V. Arias,               
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	    Pattern ipPattern = Pattern.compile(pattern);																	//Pass the ip pattern												
	    Matcher matcher = ipPattern.matcher(input);																		//Check if the ip input matches with the specified pattern
	    return matcher.matches();																						//return the bool result		
	}

	
	public void enterAction(){
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	enterAction()
	//
	// Method parameters	:	none
	//
	// Method return		:	void
	//
	// Synopsis				:   This method manage the login to the server
	//
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-09		V. Arias,               
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		String ipAddress = textFieldIPAddress.getText();																//Get the ip for the textField							
		String username = textFieldPlayerID.getText();																	//Get the player id for the textField
																														//Set the ipPattern to validate the input
		String patternIp = "^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
		String patternUser = "[a-zA-Z0-9\\._\\-]{3,6}";																	//Set the username pattern
		byte optionLogin;																								//Declarate local variable to manage the login													
		
		if( isValidIP(ipAddress,patternIp) && isValidIP(username,patternUser)) {										//Validate the username and ip according to the patterns
			try {
				playerConnection = new PlayerConnection(ipAddress);														//Established a new server conection
				optionLogin = playerConnection.Login(username);															//Call login method for the player connection object and store the result at the variable		
				if(optionLogin == 0) {																					//For a new user
					triggerWindow(username, ipAddress);																	//Call trigger window method to open the lobby window		
				}
				else if(optionLogin == 1){																				//Check the option 1 when the player return to the server
					playerConnection = new PlayerConnection(ipAddress);													//Open a new connection			
					String infoUpdate = username+","+"Online";															//Change status to online for the returning user
					playerConnection.sendInformationToServer(infoUpdate);												//Send the update		
					triggerWindow(username, ipAddress);																	//Open the window
				}
				else{
					JOptionPane.showMessageDialog(null,"Username is already taken.");									//Show a message dialog		
				};
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		else {
			JOptionPane.showMessageDialog(null, "Please enter a valid Username and IP Address.");						//Show window message in case of the user do not fill correct the inputs	
		}
	
	}
	
	public void triggerWindow(String username, String ipAddress)
	{
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	triggerWindow(String username, String ipAddress)
		//
		// Method parameters	:	String username, String ipAddress
		//
		// Method return		:	void
		//
		// Synopsis				:   This method creates a new game lobby screen
		//
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		lobby = new GameLobby();																							//Create a new game lobby instantiation
		lobby.SetPlayerID(username, ipAddress, "Online");																	//Set player on game lobby screen
		lobby.setVisible(true);																								//Set visible the game lobby screen		
		dispose();																											//Close game 	
	}
	
}
