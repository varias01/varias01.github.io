import java.awt.Point;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONObject;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

	public class PlayerConnection {
	private int port = 6066;															// establish the number of the port
	private Socket client;																// declare the socket for the client
	private DataOutputStream out;														// declare the data output stream object
	private DataInputStream in;															// declare the data input stream object
	private String incomingData;														// declare a string for the incoming data
	private HashMap<String, String> usernameStatus = new HashMap<String, String>();		// Declare the hashMap to store the users and their status
	private ArrayList<Player> players = new ArrayList<Player>();						// Declare the array list of players	
	private Map<String, Integer> score = new HashMap<String, Integer>(Map.of("Team1",0, "Team2", 0));	//Declare a hashmap to store the score of each team 
	private boolean teamsValidationResult;												//Declare a teams validation boolean variable	
	private String gameState;															//Declare game string variable

	
	public PlayerConnection(String serverName) throws IOException {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	PlayerConnection(String serverName)
	//
	// Method parameters	:	String serverName
	//
	// Method return		:	void
	//
	// Synopsis				:   This method is the constructor of the player connection. 
	//
	// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-09		V. Arias,               
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		try
	      {
	        client = new Socket(serverName, port);										// instantiate the socket to connect to server
	        OutputStream outToServer = client.getOutputStream();						// initialize the output stream
	        out = new DataOutputStream(outToServer);									// instantiate the data output stream
	        InputStream inFromServer = client.getInputStream(); 						// initialize the input stream
	        in = new DataInputStream(inFromServer);   									// instantiate the data input stream
	      }catch(IOException e)
	      {
	    	 JOptionPane.showMessageDialog(null,"No connection, try again.");			// if there is an error show an error dialog 
		  }
	}


	public String getGameState() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	getGameState()
		//
		// Method parameters	:	none
		//
		// Method return		:	String
		//
		// Synopsis				:   This method gets the game state. 
		//
		// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-09		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return gameState;																	//return the game state
	}
	
	public void sendInformationToServer(String information) 
	{
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	sendInformationToServer(String information)
	//
	// Method parameters	:	String information
	//
	// Method return		:	void
	//
	// Synopsis				:   This method send information to server from client. 
	//
	// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-09		V. Arias,               
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		String substring;													// Declare substring variable to store a portion of the information 		
		String modifiedString;												// Declare a modifiedString variable
		String [] commaSeparated;											// Declare a comma separated string array 
		String [] parts;													// Declare a parts string array
		
		try
	      {
			
	         out.writeUTF(information); 									// send information out to the server 
	         incomingData = new String(in.readUTF());						// read the incoming drawing sequence from the server
	         
	         
	         if(incomingData.length() > 1) 									// Check if the incoming data has more than 1 character 			
	         {
	        	 substring = incomingData.substring(0, 2);					// Get the first 3 characters of the incomig data
	        	
	        	 if(incomingData.substring(0, 4).equals("{\"po"))			//Get the first 4 characters of the incoming data and check if is po that means update	
	        	 {
	        		 updatePlayerList();	 								// In that case call the update player list method
	        	 }
	        	 else  if(incomingData.substring(0, 3).equals("{Te"))		//Get the first 3 characters of the incoming data and check if is te that means update the score	
	        	 {
	        		 modifiedString = incomingData.substring(1, incomingData.length() - 1);	 // Store a substring of the modified string 
	      	         commaSeparated = modifiedString.split(", ");		// Separated the modified string
	      	       
		      	       for (String item : commaSeparated) 				// Iterate through   
		      	       {
		      	            parts = item.split("=");					// Split each item by "="	
		      	          
		      	            if (parts.length == 2) 						// Check if the split result has 2 parts: a key and a value
		      	            {
		      	            	
		      	            	score.put(parts[0], Integer.valueOf(parts[1]));	// parts[0] is the key, parts[1] is the value  ////***************************
		      	            	
		      	            } 
		        	   }
	        	 }
	        	 else if(incomingData.substring(0, 1).equals("{"))			// In other case check if it is a JSON
	        	 {
		        		 modifiedString = incomingData.substring(1, incomingData.length() - 1);	 // Store a substring of the modified string 
		      	         commaSeparated = modifiedString.split(", ");		// Separated the modified string
		        		 
			      	       for (String item : commaSeparated) 				// Iterate through   
			      	       {
			      	            
			      	            parts = item.split("=");					// Split each item by "="	
		
			      	            if (parts.length == 2) 						// Check if the split result has 2 parts: a key and a value
			      	            {
			      	            	usernameStatus.put(parts[0], parts[1]);	// parts[0] is the key, parts[1] is the value
			      	            } 
			        	   }
	        	 }
	        	 else if(substring.equals("*{"))								 	//check if the user update 
	        	 {
	        		 updatePlayerList();	 										//Call the update method
	        	 }
	        	 else if(substring.equals("del"))									//Check del for clear the client when finish the match
	        	 {
	        		 gameState = "n";												//Change game state
	        		 players.clear();												//Clear the list of players
	        	 }
	        	 client.close();  													// close the server connection
	         }
	         else {
	        	 if (incomingData.equals("f")) {									//In case of the incoming data is f, is the server do not approved the teams distribution
	        		 teamsValidationResult = false;									//Set the teams validation to false  		
	        	 }
	        	 else {																//In the other case teams validation was succesful
	        		 gameState = incomingData;										//Receive the new game state	
	        		 teamsValidationResult = true;									//And set result to true
	        		 }
	         }
	      }
	      catch(Exception e)
	      {
	    	 JOptionPane.showMessageDialog(null, "No Server Connection.");		// display an error message if an exception occurs 
	         e.printStackTrace();												// and print the stack trace
	      }
	}
	
	public boolean getTeamsValidity() {
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	getTeamsValidity()
		//
		// Method parameters	:	none
		//
		// Method return		:	boolean
		//
		// Synopsis				:   This method return if the teams are valid. 
		//
		// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-10		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		if(teamsValidationResult) {															//Check if the team validation is true
			return true;																	//In that case return true
		}
		else {
			return false;																	//In the other case the teams are not valid
		}
	}
	
	public void updatePlayerList()
	{
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	 updatePlayerList()
				//
				// Method parameters	:	none
				//
				// Method return		:	void
				//
				// Synopsis				:   This method update the player list
				//
				// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-10		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		 Pattern pattern = Pattern.compile("\\{[^}]*\\}");														//Store the pattern in order to checking the incoming data
	     Matcher matchPattern = pattern.matcher(incomingData);													//Match the incoming data with the pattern		

	     while (matchPattern.find()) 																			//While match the pattern	
	     {
	            String playerJsonStr = matchPattern.group();													// Extract the JSON object string
	            JSONObject playerJson = new JSONObject(playerJsonStr);											// Parse the JSON object		

	            String playerStatus = playerJson.getString("status");											// Extract player data status
	            short lives = (short) playerJson.getInt("lives");												// Extract player lives
	            boolean isFlag = playerJson.getBoolean("isFlag");												// Extract isFlag
	            short team = (short) playerJson.getInt("team");													// Extract team 
	            Point position_point = new Point(0, 0);															// Extract the point	
	            int x = playerJson.getInt("positionX");															// Extract x position														
	            int y = playerJson.getInt("positionY");															// Extract y position					
	            position_point = new Point(x, y);																// rewrite position point
	            short radius = (short) playerJson.getInt("radius");												// Extract the radius	
	            String username = playerJson.getString("username");												// Extract the username

	            Player player = new Player();																	// Create new player
	            player = player.createPlayer(username, isFlag, lives, position_point, team, radius, playerStatus); 	// Create a new Player object and add it to the list
	            players.add(player);																			// Add the player to the list of players	
	      }

	}
	
	
	public byte Login(String username) {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	Login(String username, String ipAddress)
	//
	// Method parameters	:	String username, String ipAddress
	//
	// Method return		:	byte
	//
	// Synopsis				:   This method allow to login the user to the server. 
	//
	// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,              
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		String incomingData;											// Declare incoming data variable
		String substring;												// Declare substring data variable
		
		try {		
			
			out.writeUTF(username);										// Use the write utf to send the instruction the server

			incomingData = in.readUTF();								// Store the data in the sequence string variable
			client.close();												// Close the client instance		

			if(incomingData.equals("G"))								// Check if the length is greater than 1 
			{
				return 0;												// Return 0 in this case, it is a new username/player
			}
			else  if(incomingData.equals("E"))							//In case of receive E means user is offline
				return 1;												//Return 1
			else
				return 2;												//Return 2 in case the user is used
			
																		//close the connection instance
		} catch (IOException e) {														//catch block
			JOptionPane.showMessageDialog(null,"Connection not established");			//show a dialog message if the client couldn't connect with server
		}
		return 2;														//Return in other case
	}
		
	public ArrayList<String>  getUserStatus() {
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	// Method				:	getUserStatus()
	//
	// Method parameters	:	none
	//
	// Method return		:	ArrayList<String>
	//
	// Synopsis				:   This method allows to get a list with the user status . 
	//
	// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
	//
	// Modifications		:
	//							Date			Developers				Notes
	//							----			---------				-----
	//							2024-04-10		V. Arias,               Greeting Server
	//											J. Silva,
	//											R. Useda
	//
	// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		ArrayList<String> usersSession = new ArrayList<String>();									// Define a local  arraylist variable of users
		String tempString;																			// Declarate a temp String
		
		for (Map.Entry<String, String> usersList : usernameStatus.entrySet()) {						// Loop through the hashMap				
            tempString = usersList.getKey() + " - " + usersList.getValue()+"\n";					// Store the user information in the temp string
            usersSession.add(tempString);															// Add the tempString to the list				
        }
		return usersSession;																		// Return the arraylist
	}
	
	

	public ArrayList<Player> getPlayers()
	{
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				:	getPlayers()
		//
		// Method parameters	:	none
		//
		// Method return		:	ArrayList<Player>
		//
		// Synopsis				:   This method allows to get a list of players . 
		//
		// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
		//
		// Modifications		:
		//							Date			Developers				Notes
		//							----			---------				-----
		//							2024-04-10		V. Arias,               
		//											J. Silva,
		//											R. Useda
		//
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		return players;																	//Return the list of  players
	}
		
	public int getScore(int team)
	{
		// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
				// Method				:	getScore(int team)
				//
				// Method parameters	:	int team
				//
				// Method return		:	int
				//
				// Synopsis				:   This method allows to get score depending of the team . 
				//
				// References			:   Johnson S.(2024) GreetingServer example. Interactive Media: Network Programming.
				//
				// Modifications		:
				//							Date			Developers				Notes
				//							----			---------				-----
				//							2024-04-10		V. Arias,               
				//											J. Silva,
				//											R. Useda
				//
				// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		String Team = "Team";																	//Set team variable
		if(team == 1)																			//Check if the team is team 1
			Team += "1";
		else																					//In the other case is team 2
			Team += "2";

		return score.get(Team);																	//Return the score for the respective team		
	}
}